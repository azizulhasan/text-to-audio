const ttaGetData = async (url = '', data = {}) => {
    // Default options are marked with *
    const response = await fetch(url, {
        // headers: {
        //   "Content-Type": "application/json",
        // },
        method: 'POST', // *GET, POST, PUT, DELETE, etc.
        body: data, // body data type must match "Content-Type" header
    });
    const responseData = await response.json(); // parses JSON response into native JavaScript objects

    return responseData;
};



let TTA = {

    speechSynthesis: true,
    utterence: new SpeechSynthesisUtterance(),
    speechRecognitionIsActive: true,
    speechRecognition: window.speechRecognition || window.webkitSpeechRecognition,
    recordStatus: 'record',
    listenStatus: 'listen',
    noticeClass: 'tta_notice',
    timer: null,
    // pauseResumeTimer: () => {
    // 	speechSynthesis.pause();
    // 	//IMPORTANT!! Do not remove: Logging the object out fixes some onend firing issues.
    // 	console.log(TTA.utterence);
    // 	// Placing the speak invocation inside a callback fixes ordering and onend issues
    // 	setTimeout(() => {
    // 		speechSynthesis.resume();
    // 	}, 0);

    // 	timer = setTimeout(TTA.pauseResumeTimer, 10000)
    // },
    buttonTextArr: text_to_audio_obj.buttonTextArr,
    playButtonText: function () {
        return this.buttonTextArr.listen_text;
    },

    playButtonContent: function () {

        return '<div style="display:flex;justify-content:center;align-items:center;"><span class="dashicons dashicons-controls-play"></span> <span> ' + this.playButtonText() + '<span></span></span></div>'
    },
    replayButtonText: function () {
        return this.buttonTextArr.replay_text;
    },
    replayButtonContent: function () {
        return '<div style="display:flex;justify-content:center;align-items:center;"><span class="dashicons dashicons-image-rotate"></span> <span> ' + this.replayButtonText() + '<span></span></span></div>'
    },
    pauseButtonText: function () {
        return this.buttonTextArr.pause_text;
    },
    pauseButtonContent: function () {
        return '<div style="display:flex;justify-content:center;align-items:center;"><span class="dashicons dashicons-controls-pause"></span> <span> ' + this.pauseButtonText() + '<span></span></span></div>'
    },
    resumeButtonText: function () {
        return this.buttonTextArr.resume_text;
    },
    resumeButtonContent: function () {
        return '<div style="display:flex;justify-content:center;align-items:center;"><span class="dashicons dashicons-controls-play"></span> <span> ' + this.buttonTextArr.resume_text + '<span></span></span></div>'
    },
    recordStartButtonContent: function () {
        return '<span class="dashicons dashicons-controls-volumeoff"></span> ' + this.buttonTextArr.start_text;
    },

    recordStopButtonConten: function () {
        return '<span class="dashicons dashicons-controls-volumeon"></span> ' + this.buttonTextArr.stop_text;
    },


    displayApiMissing(button_id = '', is_dashboard = false) {
        let notice = '';
        let link = '';

        if (!this.TTA.speechRecognitionIsActive) {
            notice += 'Text To Audio: Please enable speechRecognition';
        }
        if (!this.speechSynthesis) {
            if (notice) {
                notice += ' , speechSynthesis.';
            } else {
                notice += 'Text To Audio: Please enable speechSynthesis.';
            }
        }

        if (button_id) {
            let previousSibling =
                document.getElementById(button_id).previousSibling;
            if (previousSibling) {
                notice += ` Click here to <a href="https://wordpress.org/plugins/text-to-audio/#how%20to%20enable%20%60%60speechsynthesis%60%60%20on%20firefox%3F" target="_blank">enable</a>`;
                previousSibling.style.display = 'block';
                previousSibling.innerHTML = notice;
                setTimeout(() => {
                    document.querySelector('.tta_notice').style.display =
                        'none';
                    previousSibling.innerHTML = '';
                }, 5000);
            } else {
                link +=
                    text_to_audio_obj.admin_url +
                    'admin.php?page=text-to-audio#/docs';
                notice += `\nFollow this link to enable: \n${link}`;
                alert(notice);
            }
        } else {
            if (is_dashboard) {
                link +=
                    text_to_audio_obj.admin_url +
                    'admin.php?page=text-to-audio#/docs';
            } else {
                if (
                    location.search === '?page=text-to-audio' &&
                    location.hash === '#/customize'
                ) {
                    link +=
                        text_to_audio_obj.admin_url +
                        'admin.php?page=text-to-audio#/docs';
                } else {
                    link +=
                        'https://wordpress.org/plugins/text-to-audio/#how%20to%20enable%20%60%60speechsynthesis%60%60%20on%20firefox%3F';
                }
            }
            notice += `\nFollow this link to enable: \n${link}`;
            alert(notice);
        }
        throw new Error(notice);
    },
};

var SpeechGrammarList =
    window.SpeechGrammarList || window.webkitSpeechGrammarList;
var SpeechGrammar = window.SpeechGrammar || window.webkitSpeechGrammar;
var SpeechRecognitionEvent =
    window.SpeechRecognitionEvent || window.webkitSpeechRecognitionEvent;

/**
 * Check if speechRecognition, speechSynthesis is definded in FireFox.
 * If not then show alert for enabling them.
 *
 */
if (TTA.speechRecognition == undefined) {
    TTA.speechRecognitionIsActive = false;
} else {
    var recognition = new TTA.speechRecognition();
    var grammar =
        '#JSGF V1.0; grammar colors; public <color> = aqua | azure | beige | bisque | black | blue | brown | chocolate | coral | crimson | cyan | fuchsia | ghostwhite | gold | goldenrod | gray | green | indigo | ivory | khaki | lavender | lime | linen | magenta | maroon | moccasin | navy | olive | orange | orchid | peru | pink | plum | purple | red | salmon | sienna | silver | snow | tan | teal | thistle | tomato | turquoise | violet | white | yellow ;';
    var speechRecognitionList = new SpeechGrammarList();
    speechRecognitionList.addFromString(grammar, 1);
    recognition.grammars = speechRecognitionList;
    var newGrammar = new SpeechGrammar();
    newGrammar.src =
        '#JSGF V1.0; grammar names; public <name> = chris | kirsty | mike;';
    speechRecognitionList[1] = newGrammar; // should add the new SpeechGrammar object to the list.

    /**
     * Get recording settings.
     */
    let recordData = new FormData();
    let recordSettings = {};
    recordData.append('method', 'get');
    ttaGetData(text_to_audio_obj.json_url + 'tta/v1/record', recordData)
        .then((res) => {
            recordSettings = res.data;

            recognition.continuous = recordSettings.is_record_continously
                ? recordSettings.is_record_continously
                : true;
            recognition.lang = recordSettings.tta__recording__lang
                ? recordSettings.tta__recording__lang
                : 'en-US';
            localStorage.setItem(
                'tta__sentence_delimiter',
                recordSettings.tta__sentence_delimiter,
            );
        })
        .catch((err) => {
            console.log(err);
        });

    recognition.interimResults = false;
    recognition.maxAlternatives = 2;

    /**
     *
     * restart recording
     */
    recognition.onsoundend = function () {
        TTA.recordStatus = 'record';
        let record_btn = document.getElementById('tta__start__record');
        if (record_btn) record_btn.innerHTML = TTA.recordStartButtonContent();
    };
}




// Listen content.
if (window.speechSynthesis == undefined) {
    TTA.speechSynthesis = false;
} else {
    TTA.utterence = new SpeechSynthesisUtterance();
}

/**
 *
 * @param {*} current_listening_content_id
 */

window.onload = function () {
    localStorage.setItem('recordStarted', false);
    ttaSetCurrentRecordContentId();
    if (window.speechSynthesis) speechSynthesis.cancel();
};
window.onload();

/**
 * Start recording.
 * @param {string} current_record_content_id
 */
function ttaStartRecording(
    current_record_content_id = '',
    tta__sentence_delimiter = '.',
) {
    if (
        current_record_content_id !== 'comment' &&
        current_record_content_id !== 'tta__demo_text_for_play'
    ) {
        ttaSetCurrentRecordContentId();
    }
    current_record_content_id = localStorage.getItem(
        'current_recording_content_id',
    );
    /**
     * Stop listening before recording.
     */
    if (TTA.speechSynthesis) {
        speechSynthesis.cancel();
    }

    if (!TTA.speechRecognitionIsActive) {
        if (document.getElementsByClassName('wp-block-post-title')) {
            TTA.displayApiMissing('', true);
        } else {
            TTA.displayApiMissing();
        }
    }
    /**
     * Get current recording element
     */
    let current_recording_element = ttaGetCurrrentRecordingElement(
        current_record_content_id,
    );
    if (current_recording_element === false) {
        alert('Please add a paragraph tag then start recording.');
        return;
    }

    /**
     * Change voice recognition text and icon based on condition.
     */
    ttaChangeRecordButtonText();

    /**
     * Show current recorded text.
     */
    ttaShowRecordedContent(
        current_record_content_id,
        tta__sentence_delimiter,
        current_recording_element,
    );
}

function ttaSetCurrentRecordContentId() {
    if (text_to_audio_obj.classic_editor_is_active) {
        localStorage.setItem('current_listening_content_id', 'content_ifr');
        localStorage.setItem('current_recording_content_id', 'content_ifr');
    } else if (document.getElementsByClassName('wp-block-post-title')) {
        /**
         * Get last paragraph tag id for pasting voice text.
         */
        let blockEditorContent = document.getElementsByClassName(
            'block-editor-block-list__layout',
        );

        if (blockEditorContent[0]) {
            for (child of blockEditorContent[0].children) {
                if (child.tagName === 'P') {
                    localStorage.setItem(
                        'current_recording_content_id',
                        child.getAttribute('id'),
                    );
                }
            }
        }
    }
}

/**
 * Show current recorded text.
 * @param {*} current_text
 * @param {*} tta__sentence_delimiter
 * @param {*} current_recording_element
 */
function ttaShowRecordedContent(
    current_record_content_id,
    tta__sentence_delimiter,
    current_recording_element,
) {
    let current_text = '';
    // let final_transcript = "";
    recognition.onresult = function (event) {
        let event__length = event.results.length;
        if (event.results[event__length - 1].isFinal) {
            current_text =
                event.results[event__length - 1][0].transcript +
                ttaShouldAddDelimiter(tta__sentence_delimiter);
            current_text = ttaCaptalizeString(current_text);
        }

        /**
         * Customize page id.
         */
        if (current_record_content_id == 'tta__demo_text_for_play') {
            let previous_text = current_recording_element.value;
            current_recording_element.value = previous_text + current_text;
        } else {
            let previous_text = current_recording_element.innerHTML;
            current_recording_element.innerHTML = previous_text + current_text;
        }
    };
}

/**
 * Should add delimiter.
 */
function ttaShouldAddDelimiter(tta__sentence_delimiter) {
    if (
        (window.navigator.userAgent.indexOf('Opera') ||
            window.navigator.userAgent.indexOf('OPR')) != -1
    ) {
        return tta__sentence_delimiter;
    } else if (window.navigator.userAgent.indexOf('Edg') != -1) {
        return '';
    } else if (window.navigator.userAgent.indexOf('Chrome') != -1) {
        return tta__sentence_delimiter;
    } else if (window.navigator.userAgent.indexOf('Safari') != -1) {
        return tta__sentence_delimiter;
    } else if (window.navigator.userAgent.indexOf('Firefox') != -1) {
        return tta__sentence_delimiter;
    } else if (
        window.navigator.userAgent.indexOf('MSIE') != -1 ||
        !!document.documentMode == true
    ) {
        //IF IE > 10
        return tta__sentence_delimiter;
    } else {
        return tta__sentence_delimiter;
    }
}

/**
 * Change record button text.
 */
function ttaChangeRecordButtonText() {
    let record_btn = document.getElementById('tta__start__record');
    if (TTA.recordStatus == 'stop') {
        TTA.recordStatus = 'record';
        recognition.stop();
        localStorage.setItem('recordStarted', false);
        if (record_btn) record_btn.innerHTML = TTA.recordStartButtonContent();
    } else if (TTA.recordStatus == 'record') {
        if (
            localStorage.getItem('recordStarted') == null ||
            localStorage.getItem('recordStarted') == 'false'
        ) {
            localStorage.setItem('recordStarted', true);
            recognition.start();
        }
        TTA.recordStatus = 'stop';
        if (record_btn) record_btn.innerHTML = TTA.recordStopButtonConten();
    }
}

/**
 *
 * @param {*} current_record_content_id
 * @returns
 */
function ttaGetCurrrentRecordingElement(current_record_content_id) {
    let current_recording_element = '';
    if (current_record_content_id == 'content_ifr') {
        current_recording_element = document.getElementById(
            current_record_content_id,
        ).contentWindow.document.body;
    } else {
        current_recording_element = document.getElementById(
            current_record_content_id,
        );

        /**
         * If block editor is active and current_record_content_id is null then give alert.
         */
        if (
            document.getElementsByClassName('wp-block-post-title') &&
            !current_recording_element
        ) {
            return false;
        }
    }

    return current_recording_element;
}

/**
 * Capitalize String.
 */
function ttaCaptalizeString(string) {
    if (string[0] !== ' ') {
        return string[0].toUpperCase() + string.slice(1);
    } else {
        return ' ' + string[1].toUpperCase() + string.slice(2);
    }
}

/**
 * Listent/Pause/Resume content.
 */
function ttaListenCotentInDashboard(btn_id, content, listeningSettings) {
    /**
     * Stop recording before listening.
     */
    if (TTA.speechRecognitionIsActive && recognition) {
        recognition.stop();
    }

    if (!TTA.speechSynthesis) {
        TTA.displayApiMissing('', true);
    }

    localStorage.setItem('recordStarted', false);
    localStorage.setItem('current_play_btn_id', btn_id);
    ttaSetCurrentListeningContent();

    let text = localStorage.getItem('current_listening_content');

    ttaStartListening(btn_id, text, listeningSettings);
}

function ttaSetCurrentListeningContent() {
    let current_listening_content = '';
    let text = '';
    /**
     * Classsic editor
     */
    if (text_to_audio_obj.classic_editor_is_active) {
        /**
         * Get the title.
         */
        let title = document.getElementById('title').value;
        text = title + '. ';
        current_listening_content =
            document.getElementById('content_ifr').contentWindow.document.body;

        text +=
            current_listening_content.innerText ||
            current_listening_content.textContent;
        // is block editor active.
    } else if (document.getElementsByClassName('wp-block-post-title')) {
        // Block Editor Title
        current_listening_content +=
            document.getElementsByClassName('wp-block-post-title')[0]
                .innerText + '. ';
        // Content
        let blockEditorContent = document.getElementsByClassName(
            'block-editor-block-list__layout',
        );
        for (child of blockEditorContent[0].children) {
            // Get only innerText.
            if (child.getAttribute('id')) {
                current_listening_content += document.getElementById(
                    child.getAttribute('id'),
                ).innerText;
            }
        }
        text = current_listening_content;
    }

    localStorage.setItem('current_listening_content', text);
    // }
}

/**
 * Start Reading content
 */
function ttaStartListening(btn_id, content, listeningSettings = null) {
    let listen_btn = document.getElementById(btn_id);
    TTA.utterence.text = content;
    var voices = speechSynthesis.getVoices();
    if (listeningSettings) {
        TTA.utterence.voice = voices.filter(
            (voice, i) => voice.name === listeningSettings.tta__listening_voice,
        )[0];
    } else {
        TTA.utterence.voice = voices[0];
    }
    TTA.utterence.volume = listeningSettings.tta__listening_volume
        ? listeningSettings.tta__listening_volume
        : 1; // From 0 to 1
    TTA.utterence.rate = listeningSettings.tta__listening_rate
        ? listeningSettings.tta__listening_rate
        : 1; // From 0.1 to 10
    TTA.utterence.pitch = listeningSettings.tta__listening_pitch
        ? listeningSettings.tta__listening_pitch
        : 2; // From 0 to 2
    TTA.utterence.lang = listeningSettings.tta__listening_lang
        ? listeningSettings.tta__listening_lang
        : 'en-US'; // It will be speaking language.

    if (TTA.listenStatus == 'listen') {
        //IMPORTANT!! Do not remove: Logging the object out fixes some onend firing issues.
        console.log(TTA.utterence);
        // Placing the speak invocation inside a callback fixes ordering and onend issues
        setTimeout(() => {
            speechSynthesis.speak(TTA.utterence);
        }, 0);

        TTA.timer = setTimeout(function pauseResumeTimer() {
            speechSynthesis.pause();
            //IMPORTANT!! Do not remove: Logging the object out fixes some onend firing issues.
            console.log(TTA.utterence);
            // Placing the speak invocation inside a callback fixes ordering and onend issues
            setTimeout(() => {
                speechSynthesis.resume();
            }, 0);

            TTA.timer = setTimeout(pauseResumeTimer, 10000)
        }, 10000);
        listen_btn.innerHTML = TTA.pauseButtonContent();
        listen_btn.setAttribute('title', 'Text To Audio : ' + TTA.pauseButtonText());
        TTA.listenStatus = 'pause';
    } else if (TTA.listenStatus == 'pause') {
        clearTimeout(TTA.timer);
        speechSynthesis.pause();
        listen_btn.innerHTML = TTA.resumeButtonContent();
        listen_btn.setAttribute('title', 'Text To Audio : ' + TTA.resumeButtonText());
        TTA.listenStatus = 'resume';
    } else if (TTA.listenStatus == 'resume') {
        listen_btn.innerHTML = TTA.pauseButtonContent();
        TTA.listenStatus = 'pause';
        listen_btn.setAttribute('title', 'Text To Audio : ' + TTA.pauseButtonText());
        speechSynthesis.resume();
        TTA.timer = setTimeout(function pauseResumeTimer() {
            speechSynthesis.pause();
            //IMPORTANT!! Do not remove: Logging the object out fixes some onend firing issues.
            console.log(TTA.utterence);
            // Placing the speak invocation inside a callback fixes ordering and onend issues
            setTimeout(() => {
                speechSynthesis.resume();
            }, 0);

            TTA.timer = setTimeout(pauseResumeTimer, 10000)
        }, 10000);
    }

}

/**
 * After ending reading the content.
 */
if (TTA.speechSynthesis && TTA.utterence) {
    TTA.utterence.addEventListener('end', function (event) {
        //speechSynthesis.cancel();
        clearTimeout(TTA.timer);

        let listen_btn = document.getElementById(
            localStorage.getItem('current_play_btn_id'),
        );
        listen_btn.innerHTML = TTA.replayButtonContent();
        listen_btn.setAttribute('title', 'Text To Audio : ' + TTA.replayButtonText());
        TTA.listenStatus = 'listen';
    });
}

/**
 * Read the blog
 */
function ttaListenCotentInFrontend(
    content = 'Hellow World',
    btn_id = 'wpa__listen_content',
    listeningSettings,
) {
    /**
     * Stop recording before listening.
     */
    if (TTA.speechRecognitionIsActive && recognition) {
        recognition.stop();
    }

    if (!TTA.speechSynthesis) {
        TTA.displayApiMissing(btn_id);
    }

    // Check if speechSynthesis is enabled or not?
    localStorage.setItem('recordStarted', false);
    localStorage.setItem('current_play_btn_id', btn_id);

    ttaStartListening(btn_id, content, listeningSettings);
}

/**
 * Get all textarea and start recording on focus event and stop recording on focusout event.
 */
Object.values(document.getElementsByTagName('textarea')).forEach(
    (textarea, index) => {
        let record_btn = document.getElementById('tta__start__record');
        /**
         * Start recording on focus event.
         */
        textarea.addEventListener('focus', function () {
            TTA.listenStatus = 'listen';
            let listen_btn = document.getElementById('wpa__listen_content');

            if (listen_btn) listen_btn.innerHTML = TTA.playButtonContent();
            if (listen_btn)
                listen_btn.setAttribute('title', 'Text To Audio : ' + TTA.playButtonText());
            /**
             * Start Recording.
             */
            if (
                textarea.getAttribute('id') === 'comment' ||
                textarea.getAttribute('id') === 'tta__demo_text_for_play'
            ) {
                /**
                 * Stop listening before recording.
                 */
                if (TTA.speechSynthesis) {
                    speechSynthesis.cancel();
                }
                if (!TTA.speechRecognitionIsActive) {
                    TTA.displayApiMissing();
                }
                localStorage.setItem(
                    'current_recording_content_id',
                    textarea.getAttribute('id'),
                );
                ttaStartRecording(
                    textarea.getAttribute('id'),
                    localStorage.getItem('tta__sentence_delimiter'),
                );

                TTA.recordStatus = 'record';
                if (record_btn) record_btn.innerHTML = TTA.recordStopButtonConten();
            }
        });

        /**
         * Stop recording on focusout event.
         */
        textarea.addEventListener('focusout', function () {
            // recognition.stop();
            // localStorage.setItem('recordStarted', false)
            // TTA.recordStatus = 'record';
            // record_btn.innerHTML = 'Start'
        });
    },
);

window.tta = TTA;